# AlphaFX — Forex & Binary Options Trading Platform

A full demo trading platform with live price simulation, binary options, portfolio tracking, and an admin-ready REST API backend.

---

## 🚀 Quick Start

### 1. Install dependencies
```bash
cd alphafx
npm install
```

### 2. Run the server
```bash
npm start
```

### 3. Open in browser
```
http://localhost:3000
```

---

## 📁 Project Structure

```
alphafx/
├── server/
│   └── index.js          ← Express REST API (port 3000)
├── public/
│   ├── index.html        ← Main SPA entry point
│   ├── css/
│   │   └── main.css      ← Full dark/light theme
│   └── js/
│       └── app.js        ← Frontend logic & API calls
└── package.json
```

---

## 🔌 REST API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/prices` | Live simulated prices for all pairs |
| GET | `/api/user/:id` | User profile + balance |
| POST | `/api/deposit` | Add funds (demo) |
| POST | `/api/withdraw` | Request withdrawal |
| POST | `/api/trade/forex` | Open a forex trade |
| POST | `/api/trade/close/:id` | Close a forex trade |
| POST | `/api/trade/binary` | Place a binary option |
| GET | `/api/trades/:userId` | All open/closed trades |
| GET | `/api/stats/:userId` | Portfolio stats & P&L |
| GET | `/api/transactions/:userId` | Deposit/withdrawal history |

---

## 📊 Features

- **Live price feed** — Simulated tick-by-tick prices for 9 pairs (EUR/USD, GBP/USD, USD/JPY, USD/CHF, AUD/USD, USD/CAD, XAU/USD, BTC/USD, ETH/USD)
- **Forex trading** — Buy/Sell with configurable leverage (1:10 to 1:200), stop loss & take profit
- **Binary options** — Call/Put with 1min to 1hr expiry, 75–85% payout, auto-settlement
- **Live P&L** — Positions update in real time as prices move
- **Portfolio chart** — Balance history plotted live
- **Deposit/Withdraw** — Card, Bank, Crypto, M-Pesa (demo mode; wire up real payment APIs)
- **Transaction history** — Full ledger of deposits & withdrawals
- **Light/Dark theme** — Toggle in Settings
- **Mobile responsive** — Sidebar collapses on small screens

---

## 🔧 Going Live (Checklist)

### Replace the price feed
In `server/index.js`, replace `updatePrices()` with a real broker WebSocket or REST feed:
```js
// Example: OANDA streaming API
// wss://stream-fxtrade.oanda.com/v3/accounts/{id}/pricing/stream
```

### Add real payments
- **M-Pesa**: [Safaricom Daraja API](https://developer.safaricom.co.ke/)
- **Card**: [Stripe](https://stripe.com) or [Flutterwave](https://flutterwave.com)
- **Crypto**: [Binance Pay](https://merchant.binance.com) or [NOWPayments](https://nowpayments.io)

### Add a real database
Replace the in-memory `db` object in `server/index.js` with:
- **MongoDB**: `npm install mongoose`
- **PostgreSQL**: `npm install pg` + `sequelize`
- **SQLite** (simple): `npm install better-sqlite3`

### Add authentication
```bash
npm install jsonwebtoken bcryptjs
```
Implement JWT-based login/register before going to production.

### Get licensed
- Kenya: Apply to the **Capital Markets Authority (CMA)**
- Binary options are regulated — check laws in your target markets before enabling real money trading

---

## 🛠 Development Mode (auto-restart)

```bash
npm run dev
```
*(requires `nodemon` — installed automatically via `npx`)*

---

## 📝 Default Demo Account

- **User ID**: `demo-user-1`
- **Starting balance**: $10,000 (simulated)
- **Name**: John Doe

---

Built with Node.js + Express + Chart.js + Vanilla JS.
