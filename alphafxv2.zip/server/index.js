const express = require('express');
const cors = require('cors');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// ─── Admin credentials (change before going live) ──────────────────────────
const ADMIN_CREDENTIALS = {
  username: 'superadmin',
  password: 'AlphaFX@Admin2024',
  name: 'Super Admin'
};

// Active admin sessions (token → expiry)
const adminSessions = {};

// ─── In-Memory Store ────────────────────────────────────────────────────────
let db = {
  users: {
    'demo-user-1': {
      id: 'demo-user-1',
      name: 'John Doe',
      email: 'john@example.com',
      phone: '+254 712 345 678',
      balance: 10000.00,
      demoMode: true,
      status: 'active',
      kycVerified: true,
      createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
      lastLogin: new Date().toISOString(),
      notes: ''
    },
    'demo-user-2': {
      id: 'demo-user-2',
      name: 'Jane Smith',
      email: 'jane@example.com',
      phone: '+254 798 765 432',
      balance: 25000.00,
      demoMode: false,
      status: 'active',
      kycVerified: true,
      createdAt: new Date(Date.now() - 14 * 86400000).toISOString(),
      lastLogin: new Date(Date.now() - 3600000).toISOString(),
      notes: 'VIP client'
    },
    'demo-user-3': {
      id: 'demo-user-3',
      name: 'Michael Ochieng',
      email: 'michael@example.com',
      phone: '+254 733 111 222',
      balance: 5500.00,
      demoMode: true,
      status: 'suspended',
      kycVerified: false,
      createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
      lastLogin: new Date(Date.now() - 86400000).toISOString(),
      notes: 'Pending KYC docs'
    },
    'demo-user-4': {
      id: 'demo-user-4',
      name: 'Aisha Mwangi',
      email: 'aisha@example.com',
      phone: '+254 722 999 888',
      balance: 50000.00,
      demoMode: false,
      status: 'active',
      kycVerified: true,
      createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
      lastLogin: new Date(Date.now() - 7200000).toISOString(),
      notes: 'Premium account'
    }
  },
  trades: [],
  binaryOptions: [],
  transactions: [
    { id: uuidv4(), type: 'deposit', amount: 10000, method: 'Demo', status: 'completed', date: new Date(Date.now()-86400000).toISOString(), userId: 'demo-user-1' },
    { id: uuidv4(), type: 'deposit', amount: 25000, method: 'Bank', status: 'completed', date: new Date(Date.now()-172800000).toISOString(), userId: 'demo-user-2' },
    { id: uuidv4(), type: 'withdrawal', amount: 3000, method: 'M-Pesa', status: 'pending', date: new Date(Date.now()-3600000).toISOString(), userId: 'demo-user-2' },
    { id: uuidv4(), type: 'deposit', amount: 5500, method: 'Card', status: 'completed', date: new Date(Date.now()-43200000).toISOString(), userId: 'demo-user-3' },
    { id: uuidv4(), type: 'deposit', amount: 50000, method: 'Bank', status: 'completed', date: new Date(Date.now()-2592000000).toISOString(), userId: 'demo-user-4' },
  ],
  adminLogs: []
};

// ─── Admin log helper ────────────────────────────────────────────────────────
function logAdmin(action, targetUserId, details) {
  db.adminLogs.unshift({
    id: uuidv4(),
    action,
    targetUserId,
    details,
    timestamp: new Date().toISOString()
  });
  if (db.adminLogs.length > 200) db.adminLogs.pop();
}

// ─── Live prices ─────────────────────────────────────────────────────────────
let prices = {
  'EUR/USD': 1.08542, 'GBP/USD': 1.26813, 'USD/JPY': 149.423,
  'USD/CHF': 0.90145, 'AUD/USD': 0.64872, 'USD/CAD': 1.36541,
  'XAU/USD': 2338.50, 'BTC/USD': 67421.00, 'ETH/USD': 3542.00
};

function updatePrices() {
  Object.keys(prices).forEach(pair => {
    const v = prices[pair] > 1000 ? 0.003 : 0.0003;
    prices[pair] = parseFloat((prices[pair] * (1 + (Math.random() - 0.499) * v)).toFixed(prices[pair] > 100 ? 2 : 5));
  });
  const now = Date.now();
  db.binaryOptions.forEach(opt => {
    if (opt.status === 'open' && now >= opt.expiresAt) {
      const cur = prices[opt.pair];
      const won = opt.direction === 'call' ? cur > opt.entryPrice : cur < opt.entryPrice;
      opt.status = won ? 'won' : 'lost';
      opt.exitPrice = cur;
      opt.settledAt = new Date().toISOString();
      if (won && db.users[opt.userId]) {
        db.users[opt.userId].balance = parseFloat((db.users[opt.userId].balance + opt.payout).toFixed(2));
      }
    }
  });
}
setInterval(updatePrices, 1500);

// ─── Admin Auth Middleware ───────────────────────────────────────────────────
function requireAdmin(req, res, next) {
  const token = req.headers['x-admin-token'];
  if (!token || !adminSessions[token] || adminSessions[token] < Date.now()) {
    return res.status(401).json({ error: 'Unauthorized. Please log in as admin.' });
  }
  next();
}

// ══════════════════════════════════════════════════════════════════════════════
// ADMIN ROUTES
// ══════════════════════════════════════════════════════════════════════════════

// Admin login
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (username !== ADMIN_CREDENTIALS.username || password !== ADMIN_CREDENTIALS.password) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  const token = uuidv4();
  adminSessions[token] = Date.now() + 8 * 3600 * 1000; // 8hr session
  logAdmin('LOGIN', null, 'Admin logged in');
  res.json({ success: true, token, name: ADMIN_CREDENTIALS.name });
});

// Admin logout
app.post('/api/admin/logout', requireAdmin, (req, res) => {
  delete adminSessions[req.headers['x-admin-token']];
  res.json({ success: true });
});

// Dashboard summary
app.get('/api/admin/dashboard', requireAdmin, (req, res) => {
  const users = Object.values(db.users);
  const totalBalance = users.reduce((s, u) => s + u.balance, 0);
  const totalDeposits = db.transactions.filter(t => t.type === 'deposit' && t.status === 'completed').reduce((s, t) => s + t.amount, 0);
  const totalWithdrawals = db.transactions.filter(t => t.type === 'withdrawal').reduce((s, t) => s + t.amount, 0);
  const pendingWithdrawals = db.transactions.filter(t => t.type === 'withdrawal' && t.status === 'pending');
  res.json({
    totalUsers: users.length,
    activeUsers: users.filter(u => u.status === 'active').length,
    suspendedUsers: users.filter(u => u.status === 'suspended').length,
    totalBalance: parseFloat(totalBalance.toFixed(2)),
    totalDeposits: parseFloat(totalDeposits.toFixed(2)),
    totalWithdrawals: parseFloat(totalWithdrawals.toFixed(2)),
    pendingWithdrawals: pendingWithdrawals.length,
    pendingWithdrawalAmount: pendingWithdrawals.reduce((s,t)=>s+t.amount,0),
    openTrades: db.trades.filter(t => t.status === 'open').length,
    openBinary: db.binaryOptions.filter(t => t.status === 'open').length,
    recentTransactions: db.transactions.slice(-10).reverse()
  });
});

// List all users
app.get('/api/admin/users', requireAdmin, (req, res) => {
  const users = Object.values(db.users).map(u => ({
    ...u,
    tradeCount: db.trades.filter(t => t.userId === u.id).length,
    binaryCount: db.binaryOptions.filter(t => t.userId === u.id).length
  }));
  res.json(users);
});

// Get single user detail
app.get('/api/admin/users/:id', requireAdmin, (req, res) => {
  const user = db.users[req.params.id];
  if (!user) return res.status(404).json({ error: 'User not found' });
  const forex = db.trades.filter(t => t.userId === req.params.id);
  const binary = db.binaryOptions.filter(t => t.userId === req.params.id);
  const txs = db.transactions.filter(t => t.userId === req.params.id);
  res.json({ ...user, forex, binary, transactions: txs.reverse() });
});

// Update user balance
app.post('/api/admin/users/:id/balance', requireAdmin, (req, res) => {
  const user = db.users[req.params.id];
  if (!user) return res.status(404).json({ error: 'User not found' });
  const { amount, type, note } = req.body; // type: 'set' | 'add' | 'subtract'
  const prev = user.balance;
  if (type === 'set') user.balance = parseFloat(parseFloat(amount).toFixed(2));
  else if (type === 'add') user.balance = parseFloat((user.balance + parseFloat(amount)).toFixed(2));
  else if (type === 'subtract') user.balance = parseFloat((user.balance - parseFloat(amount)).toFixed(2));
  if (user.balance < 0) user.balance = 0;
  const tx = { id: uuidv4(), type: 'admin_adjustment', amount: parseFloat(amount), adjustType: type, note: note || 'Admin adjustment', status: 'completed', date: new Date().toISOString(), userId: user.id };
  db.transactions.push(tx);
  logAdmin('BALANCE_CHANGE', user.id, `${type} $${amount} (was $${prev} → now $${user.balance}). Note: ${note||'—'}`);
  res.json({ success: true, newBalance: user.balance, transaction: tx });
});

// Update user profile
app.post('/api/admin/users/:id/profile', requireAdmin, (req, res) => {
  const user = db.users[req.params.id];
  if (!user) return res.status(404).json({ error: 'User not found' });
  const allowed = ['name', 'email', 'phone', 'status', 'kycVerified', 'demoMode', 'notes'];
  allowed.forEach(k => { if (req.body[k] !== undefined) user[k] = req.body[k]; });
  logAdmin('PROFILE_UPDATE', user.id, `Updated: ${Object.keys(req.body).filter(k=>allowed.includes(k)).join(', ')}`);
  res.json({ success: true, user });
});

// Suspend / activate user
app.post('/api/admin/users/:id/status', requireAdmin, (req, res) => {
  const user = db.users[req.params.id];
  if (!user) return res.status(404).json({ error: 'User not found' });
  const { status } = req.body;
  user.status = status;
  logAdmin('STATUS_CHANGE', user.id, `Status set to ${status}`);
  res.json({ success: true, status });
});

// Force close all trades for a user
app.post('/api/admin/users/:id/close-trades', requireAdmin, (req, res) => {
  const userId = req.params.id;
  const open = db.trades.filter(t => t.userId === userId && t.status === 'open');
  open.forEach(t => {
    const exitPrice = prices[t.pair];
    const diff = t.direction === 'buy' ? exitPrice - t.entryPrice : t.entryPrice - exitPrice;
    t.pnl = parseFloat((diff * t.amount * t.leverage).toFixed(2));
    t.status = 'closed'; t.exitPrice = exitPrice; t.closedAt = new Date().toISOString();
    if (db.users[userId]) db.users[userId].balance = parseFloat((db.users[userId].balance + t.pnl).toFixed(2));
  });
  logAdmin('CLOSE_TRADES', userId, `Force-closed ${open.length} forex trade(s)`);
  res.json({ success: true, closed: open.length });
});

// Approve / reject withdrawal
app.post('/api/admin/transactions/:txId/status', requireAdmin, (req, res) => {
  const tx = db.transactions.find(t => t.id === req.params.txId);
  if (!tx) return res.status(404).json({ error: 'Transaction not found' });
  const prev = tx.status;
  tx.status = req.body.status;
  tx.adminNote = req.body.note || '';
  tx.processedAt = new Date().toISOString();
  logAdmin('TX_STATUS', tx.userId, `Transaction ${tx.id} changed from ${prev} to ${req.body.status}`);
  res.json({ success: true, transaction: tx });
});

// All transactions (admin view)
app.get('/api/admin/transactions', requireAdmin, (req, res) => {
  const txs = [...db.transactions].reverse();
  res.json(txs);
});

// Admin activity log
app.get('/api/admin/logs', requireAdmin, (req, res) => {
  res.json(db.adminLogs);
});

// Create new user
app.post('/api/admin/users', requireAdmin, (req, res) => {
  const { name, email, phone, balance, demoMode } = req.body;
  if (!name || !email) return res.status(400).json({ error: 'Name and email required' });
  const id = 'user-' + uuidv4().slice(0, 8);
  const user = { id, name, email, phone: phone || '', balance: parseFloat(balance)||0, demoMode: !!demoMode, status: 'active', kycVerified: false, createdAt: new Date().toISOString(), lastLogin: null, notes: '' };
  db.users[id] = user;
  if (user.balance > 0) db.transactions.push({ id: uuidv4(), type: 'deposit', amount: user.balance, method: 'Admin', status: 'completed', date: new Date().toISOString(), userId: id });
  logAdmin('CREATE_USER', id, `Created user ${name} (${email}) with balance $${user.balance}`);
  res.json({ success: true, user });
});

// Delete user
app.delete('/api/admin/users/:id', requireAdmin, (req, res) => {
  const user = db.users[req.params.id];
  if (!user) return res.status(404).json({ error: 'User not found' });
  logAdmin('DELETE_USER', req.params.id, `Deleted user ${user.name}`);
  delete db.users[req.params.id];
  res.json({ success: true });
});

// ══════════════════════════════════════════════════════════════════════════════
// EXISTING USER ROUTES (unchanged)
// ══════════════════════════════════════════════════════════════════════════════

app.get('/api/prices', (req, res) => res.json({ prices, timestamp: Date.now() }));

app.get('/api/user/:id', (req, res) => {
  const user = db.users[req.params.id];
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(user);
});

app.post('/api/deposit', (req, res) => {
  const { userId = 'demo-user-1', amount, method } = req.body;
  if (!amount || amount < 10) return res.status(400).json({ error: 'Minimum deposit is $10' });
  db.users[userId].balance = parseFloat((db.users[userId].balance + parseFloat(amount)).toFixed(2));
  const tx = { id: uuidv4(), type: 'deposit', amount: parseFloat(amount), method: method||'Demo', status: 'completed', date: new Date().toISOString(), userId };
  db.transactions.push(tx);
  res.json({ success: true, newBalance: db.users[userId].balance, transaction: tx });
});

app.post('/api/withdraw', (req, res) => {
  const { userId = 'demo-user-1', amount, destination } = req.body;
  const user = db.users[userId];
  if (!amount || amount < 10) return res.status(400).json({ error: 'Minimum withdrawal is $10' });
  if (amount > user.balance) return res.status(400).json({ error: 'Insufficient balance' });
  user.balance = parseFloat((user.balance - parseFloat(amount)).toFixed(2));
  const tx = { id: uuidv4(), type: 'withdrawal', amount: parseFloat(amount), destination: destination||'Bank', status: 'pending', date: new Date().toISOString(), userId };
  db.transactions.push(tx);
  res.json({ success: true, newBalance: user.balance, transaction: tx });
});

app.post('/api/trade/forex', (req, res) => {
  const { userId = 'demo-user-1', pair, direction, amount, leverage = 50, stopLoss, takeProfit } = req.body;
  const user = db.users[userId];
  if (!prices[pair]) return res.status(400).json({ error: 'Invalid pair' });
  if (!['buy', 'sell'].includes(direction)) return res.status(400).json({ error: 'Invalid direction' });
  if (!amount || amount < 10) return res.status(400).json({ error: 'Minimum trade is $10' });
  const margin = parseFloat((amount / leverage).toFixed(2));
  if (margin > user.balance) return res.status(400).json({ error: 'Insufficient margin' });
  const trade = { id: uuidv4(), userId, type: 'forex', pair, direction, amount: parseFloat(amount), leverage, margin, entryPrice: prices[pair], currentPrice: prices[pair], stopLoss: parseFloat(stopLoss)||null, takeProfit: parseFloat(takeProfit)||null, pnl: 0, status: 'open', openedAt: new Date().toISOString() };
  db.trades.push(trade);
  res.json({ success: true, trade });
});

app.post('/api/trade/close/:tradeId', (req, res) => {
  const trade = db.trades.find(t => t.id === req.params.tradeId);
  if (!trade) return res.status(404).json({ error: 'Trade not found' });
  if (trade.status !== 'open') return res.status(400).json({ error: 'Trade already closed' });
  const exitPrice = prices[trade.pair];
  const diff = trade.direction === 'buy' ? exitPrice - trade.entryPrice : trade.entryPrice - exitPrice;
  const pnl = parseFloat((diff * trade.amount * trade.leverage).toFixed(2));
  trade.status = 'closed'; trade.exitPrice = exitPrice; trade.pnl = pnl; trade.closedAt = new Date().toISOString();
  db.users[trade.userId].balance = parseFloat((db.users[trade.userId].balance + pnl).toFixed(2));
  res.json({ success: true, trade, pnl, newBalance: db.users[trade.userId].balance });
});

app.post('/api/trade/binary', (req, res) => {
  const { userId = 'demo-user-1', pair, direction, stake, expiryMinutes = 15, payoutPercent = 85 } = req.body;
  const user = db.users[userId];
  if (!prices[pair]) return res.status(400).json({ error: 'Invalid pair' });
  if (!['call', 'put'].includes(direction)) return res.status(400).json({ error: 'Invalid direction' });
  if (!stake || stake < 10) return res.status(400).json({ error: 'Minimum stake is $10' });
  if (stake > user.balance) return res.status(400).json({ error: 'Insufficient balance' });
  user.balance = parseFloat((user.balance - parseFloat(stake)).toFixed(2));
  const payout = parseFloat((stake * (1 + payoutPercent / 100)).toFixed(2));
  const option = { id: uuidv4(), userId, type: 'binary', pair, direction, stake: parseFloat(stake), payout, payoutPercent, entryPrice: prices[pair], exitPrice: null, expiryMinutes, expiresAt: Date.now() + expiryMinutes * 60 * 1000, status: 'open', openedAt: new Date().toISOString(), settledAt: null };
  db.binaryOptions.push(option);
  res.json({ success: true, option, newBalance: user.balance });
});

app.get('/api/trades/:userId', (req, res) => {
  const userId = req.params.userId;
  const forex = db.trades.filter(t => t.userId === userId).map(t => {
    if (t.status === 'open') { const d = t.direction === 'buy' ? prices[t.pair] - t.entryPrice : t.entryPrice - prices[t.pair]; t.currentPrice = prices[t.pair]; t.pnl = parseFloat((d * t.amount * t.leverage).toFixed(2)); }
    return t;
  });
  const binary = db.binaryOptions.filter(t => t.userId === userId).map(o => ({ ...o, currentPrice: prices[o.pair], timeLeft: Math.max(0, o.expiresAt - Date.now()) }));
  res.json({ forex, binary });
});

app.get('/api/transactions/:userId', (req, res) => {
  res.json(db.transactions.filter(t => t.userId === req.params.userId).reverse());
});

app.get('/api/stats/:userId', (req, res) => {
  const userId = req.params.userId;
  const user = db.users[userId];
  if (!user) return res.status(404).json({ error: 'User not found' });
  const allForex = db.trades.filter(t => t.userId === userId);
  const allBinary = db.binaryOptions.filter(t => t.userId === userId);
  const closedBinary = allBinary.filter(t => t.status !== 'open');
  const wonBinary = allBinary.filter(t => t.status === 'won');
  const totalPnl = allForex.reduce((s,t) => s+(t.pnl||0), 0)
    + allBinary.filter(t=>t.status==='won').reduce((s,t)=>s+(t.payout-t.stake),0)
    - allBinary.filter(t=>t.status==='lost').reduce((s,t)=>s+t.stake,0);
  res.json({ balance: user.balance, totalPnl: parseFloat(totalPnl.toFixed(2)), openForex: allForex.filter(t=>t.status==='open').length, openBinary: allBinary.filter(t=>t.status==='open').length, winRate: closedBinary.length ? Math.round((wonBinary.length/closedBinary.length)*100) : 0, totalTrades: allForex.length + allBinary.length });
});

app.get('*', (req, res) => {
  if (req.path === '/admin' || req.path === '/admin/') return res.sendFile(path.join(__dirname, '../public/admin.html'));
  if (req.path === '/login' || req.path === '/login/') return res.sendFile(path.join(__dirname, '../public/login.html'));
  if (req.path === '/register' || req.path === '/register/') return res.sendFile(path.join(__dirname, '../public/register.html'));
  if (req.path === '/forgot-password') return res.sendFile(path.join(__dirname, '../public/forgot-password.html'));
  if (req.path === '/app' || req.path === '/app/') return res.sendFile(path.join(__dirname, '../public/index.html'));
  if (req.path === '/' || req.path === '') return res.sendFile(path.join(__dirname, '../public/landing.html'));
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

app.listen(PORT, () => {
  console.log(`\n🚀 AlphaFX Trading Platform`);
  console.log(`   Landing Page:   http://localhost:${PORT}`);
  console.log(`   Sign In:        http://localhost:${PORT}/login`);
  console.log(`   Register:       http://localhost:${PORT}/register`);
  console.log(`   Trading App:    http://localhost:${PORT}/app`);
  console.log(`   Admin Panel:    http://localhost:${PORT}/admin`);
  console.log(`   Admin login:    superadmin / AlphaFX@Admin2024\n`);
});
