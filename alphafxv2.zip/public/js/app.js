/* ── Config ─────────────────────────────────────────────────── */
const API = 'http://localhost:3000/api';
const USER_ID = 'demo-user-1';

/* ── State ──────────────────────────────────────────────────── */
let state = {
  prices: {},
  balance: 10000,
  trades: { forex: [], binary: [] },
  fxDir: 'buy',
  binDir: 'call',
  mainChart: null,
  forexChart: null,
  binaryChart: null,
  portfolioChart: null,
  priceHistory: {},
  tickInterval: null,
  tradeInterval: null,
  balanceHistory: [],
  currentView: 'dashboard'
};

/* ── Init ───────────────────────────────────────────────────── */
window.addEventListener('DOMContentLoaded', async () => {
  await fetchPrices();
  await fetchStats();
  await fetchTrades();
  buildTicker();
  buildSidePrices();
  buildPairsGrid();
  initMainChart();
  updateForexCalc();
  updateBinaryCalc();

  state.tickInterval = setInterval(async () => {
    await fetchPrices();
    updateTicker();
    updateSidePrices();
    updateCharts();
    updateOpenPositions();
    updateBinaryTimers();
  }, 1500);

  state.tradeInterval = setInterval(async () => {
    await fetchTrades();
    await fetchStats();
  }, 5000);
});

/* ── API ────────────────────────────────────────────────────── */
async function api(path, method = 'GET', body = null) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  try {
    const res = await fetch(API + path, opts);
    return await res.json();
  } catch (e) {
    console.error('API error:', path, e);
    return null;
  }
}

async function fetchPrices() {
  const data = await api('/prices');
  if (!data) return;
  state.prices = data.prices;
  Object.entries(data.prices).forEach(([pair, price]) => {
    if (!state.priceHistory[pair]) state.priceHistory[pair] = [];
    state.priceHistory[pair].push(price);
    if (state.priceHistory[pair].length > 80) state.priceHistory[pair].shift();
  });
}

async function fetchStats() {
  const data = await api(`/stats/${USER_ID}`);
  if (!data) return;
  state.balance = data.balance;
  state.balanceHistory.push(data.balance);
  if (state.balanceHistory.length > 60) state.balanceHistory.shift();

  document.getElementById('header-balance').textContent = '$' + fmt(data.balance);
  const pnl = data.totalPnl;
  const pnlEl = document.getElementById('stat-pnl');
  if (pnlEl) {
    pnlEl.textContent = (pnl >= 0 ? '+' : '') + '$' + fmt(Math.abs(pnl));
    pnlEl.className = 'stat-val ' + (pnl >= 0 ? 'up' : 'down');
  }
  const pct = ((pnl / 10000) * 100).toFixed(2);
  const pctEl = document.getElementById('stat-pnl-pct');
  if (pctEl) pctEl.textContent = (pnl >= 0 ? '+' : '') + pct + '% return';

  const openEl = document.getElementById('stat-open');
  if (openEl) openEl.textContent = data.openForex + data.openBinary;
  const openSub = document.getElementById('stat-open-sub');
  if (openSub) openSub.textContent = `${data.openForex} Forex · ${data.openBinary} Binary`;

  const winEl = document.getElementById('stat-win');
  if (winEl) winEl.textContent = data.winRate ? data.winRate + '%' : '—';

  const portBal = document.getElementById('port-balance');
  if (portBal) portBal.textContent = '$' + fmt(data.balance);
  const portRet = document.getElementById('port-return');
  if (portRet) {
    const r = ((data.balance - 10000) / 100).toFixed(2);
    portRet.textContent = (r >= 0 ? '+' : '') + r + '%';
    portRet.className = 'stat-val ' + (r >= 0 ? 'up' : 'down');
  }

  const bsActive = document.getElementById('bs-active');
  if (bsActive) bsActive.textContent = data.openBinary;
}

async function fetchTrades() {
  const data = await api(`/trades/${USER_ID}`);
  if (!data) return;
  state.trades = data;
  renderOpenPositions();
  renderBinaryPositions();
  renderPortfolioTrades();
}

/* ── Ticker ─────────────────────────────────────────────────── */
const TICKER_PAIRS = ['EUR/USD','GBP/USD','USD/JPY','XAU/USD','BTC/USD'];

function buildTicker() {
  const el = document.getElementById('ticker');
  el.innerHTML = TICKER_PAIRS.map(p => `
    <div class="tick-item" id="tick-${p.replace('/','_')}">
      <div class="tick-pair">${p}</div>
      <div class="tick-price">${fmtPrice(p, state.prices[p] || 0)}</div>
      <div class="tick-chg up">—</div>
    </div>
  `).join('');
}

function updateTicker() {
  TICKER_PAIRS.forEach(p => {
    const id = 'tick-' + p.replace('/','_');
    const el = document.getElementById(id);
    if (!el) return;
    const hist = state.priceHistory[p] || [];
    const cur = hist[hist.length - 1] || 0;
    const prev = hist[hist.length - 2] || cur;
    const chg = prev ? ((cur - prev) / prev * 100) : 0;
    el.querySelector('.tick-price').textContent = fmtPrice(p, cur);
    const chgEl = el.querySelector('.tick-chg');
    chgEl.textContent = (chg >= 0 ? '+' : '') + chg.toFixed(2) + '%';
    chgEl.className = 'tick-chg ' + (chg >= 0 ? 'up' : 'down');
  });

  // Update main price display
  const eur = state.prices['EUR/USD'];
  if (eur) {
    const hist = state.priceHistory['EUR/USD'] || [];
    const prev = hist[hist.length - 2] || eur;
    const diff = eur - prev;
    const pct = prev ? (diff / prev * 100) : 0;
    const dp = document.getElementById('dash-price');
    const dc = document.getElementById('dash-change');
    const db = document.getElementById('dash-bid');
    const da = document.getElementById('dash-ask');
    if (dp) dp.textContent = eur.toFixed(5);
    if (dc) {
      dc.textContent = (diff >= 0 ? '+' : '') + diff.toFixed(5) + ' (' + (pct >= 0 ? '+' : '') + pct.toFixed(2) + '%)';
      dc.className = 'price-change ' + (diff >= 0 ? 'up' : 'down');
    }
    if (db) db.textContent = (eur - 0.00002).toFixed(5);
    if (da) da.textContent = (eur + 0.00002).toFixed(5);
  }
}

function buildSidePrices() {
  const el = document.getElementById('side-prices');
  if (!el) return;
  el.innerHTML = '<div class="section-title" style="margin:0 0 8px">Live Prices</div>' +
    Object.keys(state.prices).slice(0,7).map(p => `
      <div class="side-price-item" id="sp-${p.replace('/','_')}">
        <span class="sp-pair">${p}</span>
        <span class="sp-price">${fmtPrice(p, state.prices[p])}</span>
      </div>
    `).join('');
}

function updateSidePrices() {
  Object.entries(state.prices).forEach(([p, price]) => {
    const el = document.getElementById('sp-' + p.replace('/','_'));
    if (el) el.querySelector('.sp-price').textContent = fmtPrice(p, price);
  });
}

function buildPairsGrid() {
  const el = document.getElementById('pairs-grid');
  if (!el) return;
  el.innerHTML = Object.entries(state.prices).map(([p, price]) => {
    const hist = state.priceHistory[p] || [price];
    const prev = hist[hist.length - 2] || price;
    const chg = ((price - prev) / (prev || 1) * 100).toFixed(2);
    return `
      <div class="pair-card" onclick="selectPair('${p}')">
        <div class="pair-card-name">${p}</div>
        <div class="pair-card-price">${fmtPrice(p, price)}</div>
        <div class="pair-card-chg ${chg >= 0 ? 'up' : 'down'}">${chg >= 0 ? '+' : ''}${chg}%</div>
      </div>
    `;
  }).join('');
}

function selectPair(pair) {
  document.getElementById('f-pair').value = pair;
  document.getElementById('b-pair').value = pair;
}

/* ── Charts ─────────────────────────────────────────────────── */
function chartDefaults() {
  return {
    responsive: true,
    maintainAspectRatio: false,
    animation: { duration: 0 },
    plugins: { legend: { display: false } },
    scales: {
      x: { display: false },
      y: { ticks: { color: '#4a6080', font: { size: 11 } }, grid: { color: '#1e2a45' } }
    }
  };
}

function initMainChart() {
  const ctx = document.getElementById('main-chart');
  if (!ctx) return;
  const hist = state.priceHistory['EUR/USD'] || [];
  state.mainChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: hist.map((_,i) => i),
      datasets: [{
        data: hist,
        borderColor: '#38bdf8',
        borderWidth: 1.5,
        pointRadius: 0,
        fill: true,
        backgroundColor: 'rgba(56,189,248,0.06)',
        tension: 0.3
      }]
    },
    options: chartDefaults()
  });
}

function initBinaryChartView() {
  const ctx = document.getElementById('binary-chart');
  if (!ctx || state.binaryChart) return;
  const hist = state.priceHistory['EUR/USD'] || [];
  state.binaryChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: hist.map((_,i) => i),
      datasets: [{
        data: hist,
        borderColor: '#f59e0b',
        borderWidth: 2,
        pointRadius: 0,
        fill: false,
        tension: 0.4
      }]
    },
    options: chartDefaults()
  });
}

function initPortfolioChart() {
  const ctx = document.getElementById('portfolio-chart');
  if (!ctx || state.portfolioChart) return;
  const data = state.balanceHistory.length > 1 ? state.balanceHistory : [10000, state.balance];
  state.portfolioChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: data.map((_,i) => i),
      datasets: [{
        data,
        borderColor: '#22c55e',
        borderWidth: 2,
        pointRadius: 0,
        fill: true,
        backgroundColor: 'rgba(34,197,94,0.07)',
        tension: 0.4
      }]
    },
    options: chartDefaults()
  });
}

function updateCharts() {
  const hist = state.priceHistory['EUR/USD'] || [];
  if (state.mainChart) {
    state.mainChart.data.labels = hist.map((_,i) => i);
    state.mainChart.data.datasets[0].data = [...hist];
    state.mainChart.update('none');
  }
  if (state.binaryChart) {
    state.binaryChart.data.labels = hist.map((_,i) => i);
    state.binaryChart.data.datasets[0].data = [...hist];
    state.binaryChart.update('none');
  }
  if (state.portfolioChart) {
    const bal = state.balanceHistory;
    state.portfolioChart.data.labels = bal.map((_,i) => i);
    state.portfolioChart.data.datasets[0].data = [...bal];
    state.portfolioChart.update('none');
  }
}

/* ── Positions ──────────────────────────────────────────────── */
function renderOpenPositions() {
  const el = document.getElementById('open-positions-list');
  if (!el) return;
  const open = state.trades.forex.filter(t => t.status === 'open');
  if (!open.length && !state.trades.binary.filter(t=>t.status==='open').length) {
    el.innerHTML = '<div class="empty-state"><i class="ti ti-chart-candle"></i><p>No open positions yet. Place a trade to get started.</p></div>';
    return;
  }
  el.innerHTML = open.map(t => {
    const pnl = t.pnl || 0;
    return `
      <div class="position-card">
        <div>
          <div class="pos-pair">${t.pair} <span class="badge badge-${t.direction}">${t.direction.toUpperCase()}</span></div>
          <div class="pos-detail">Entry: ${fmtPrice(t.pair, t.entryPrice)} · Size: $${t.amount} · ${t.leverage}x</div>
        </div>
        <div style="text-align:right">
          <div class="pos-pnl ${pnl >= 0 ? 'up' : 'down'}">${pnl >= 0 ? '+' : ''}$${fmt(Math.abs(pnl))}</div>
          <div class="pos-actions" style="margin-top:6px">
            <button class="btn-close-pos" onclick="closeTrade('${t.id}')">Close</button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function updateOpenPositions() {
  state.trades.forex.filter(t => t.status === 'open').forEach(t => {
    const cur = state.prices[t.pair];
    if (!cur) return;
    const diff = t.direction === 'buy' ? cur - t.entryPrice : t.entryPrice - cur;
    t.pnl = parseFloat((diff * t.amount * t.leverage).toFixed(2));
    t.currentPrice = cur;
  });
  renderOpenPositions();
}

function renderBinaryPositions() {
  const el = document.getElementById('binary-positions');
  if (!el) return;
  const open = state.trades.binary.filter(t => t.status === 'open');
  if (!open.length) {
    el.innerHTML = '<div class="empty-state"><i class="ti ti-clock"></i><p>No active binary options.</p></div>';
    const bsWon = document.getElementById('bs-won');
    const bsLost = document.getElementById('bs-lost');
    if (bsWon) bsWon.textContent = state.trades.binary.filter(t=>t.status==='won').length;
    if (bsLost) bsLost.textContent = state.trades.binary.filter(t=>t.status==='lost').length;
    return;
  }
  el.innerHTML = open.map(o => {
    const left = Math.max(0, o.expiresAt - Date.now());
    const mins = Math.floor(left / 60000);
    const secs = Math.floor((left % 60000) / 1000);
    const timer = String(mins).padStart(2,'0') + ':' + String(secs).padStart(2,'0');
    return `
      <div class="bin-card" id="bincard-${o.id}">
        <div>
          <div class="pos-pair">${o.pair} <span class="badge badge-${o.direction}">${o.direction.toUpperCase()}</span></div>
          <div class="pos-detail">Stake: $${fmt(o.stake)} · Win: $${fmt(o.payout)}</div>
        </div>
        <div style="text-align:right">
          <div class="bin-timer" id="btimer-${o.id}">${timer}</div>
          <div class="pos-detail" style="margin-top:3px">Entry: ${fmtPrice(o.pair, o.entryPrice)}</div>
        </div>
      </div>
    `;
  }).join('');

  if (document.getElementById('bs-won')) document.getElementById('bs-won').textContent = state.trades.binary.filter(t=>t.status==='won').length;
  if (document.getElementById('bs-lost')) document.getElementById('bs-lost').textContent = state.trades.binary.filter(t=>t.status==='lost').length;
}

function updateBinaryTimers() {
  state.trades.binary.filter(t => t.status === 'open').forEach(o => {
    const el = document.getElementById('btimer-' + o.id);
    if (!el) return;
    const left = Math.max(0, o.expiresAt - Date.now());
    const mins = Math.floor(left / 60000);
    const secs = Math.floor((left % 60000) / 1000);
    el.textContent = String(mins).padStart(2,'0') + ':' + String(secs).padStart(2,'0');
  });
}

function renderPortfolioTrades() {
  const el = document.getElementById('portfolio-trades');
  if (!el) return;
  const all = [...state.trades.forex, ...state.trades.binary];
  if (!all.length) {
    el.innerHTML = '<div class="empty-state"><i class="ti ti-briefcase"></i><p>No trades yet.</p></div>';
    return;
  }
  el.innerHTML = all.map(t => {
    const isBinary = t.type === 'binary';
    const pnl = isBinary
      ? (t.status === 'won' ? t.payout - t.stake : t.status === 'lost' ? -t.stake : 0)
      : (t.pnl || 0);
    const badgeClass = isBinary ? `badge-${t.direction}` : `badge-${t.direction}`;
    const statusClass = t.status === 'open' ? 'badge-open' : t.status === 'won' ? 'badge-won' : t.status === 'lost' ? 'badge-lost' : 'badge-closed';
    return `
      <div class="position-card">
        <div>
          <div class="pos-pair">${t.pair} <span class="badge ${badgeClass}">${(t.direction||'').toUpperCase()}</span></div>
          <div class="pos-detail">${isBinary ? 'Binary · Stake: $'+fmt(t.stake) : 'Forex · $'+t.amount+' · '+t.leverage+'x'} · <span class="badge ${statusClass}">${t.status}</span></div>
        </div>
        <div style="text-align:right">
          <div class="pos-pnl ${pnl >= 0 ? 'up' : 'down'}">${pnl !== 0 ? (pnl >= 0 ? '+' : '') + '$' + fmt(Math.abs(pnl)) : '—'}</div>
        </div>
      </div>
    `;
  }).join('');
}

/* ── Trade Actions ──────────────────────────────────────────── */
async function placeFxTrade() {
  const btn = document.getElementById('forex-submit');
  btn.disabled = true; btn.textContent = 'Placing...';

  const body = {
    userId: USER_ID,
    pair: document.getElementById('f-pair').value,
    direction: state.fxDir,
    amount: parseFloat(document.getElementById('f-amount').value),
    leverage: parseInt(document.getElementById('f-leverage').value),
    stopLoss: document.getElementById('f-sl').value,
    takeProfit: document.getElementById('f-tp').value
  };

  const res = await api('/trade/forex', 'POST', body);
  btn.disabled = false; btn.innerHTML = '<i class="ti ti-chart-candle"></i> Place Trade';

  if (!res || res.error) { toast(res?.error || 'Failed to place trade', true); return; }
  toast(`✓ ${body.direction.toUpperCase()} ${body.pair} · $${fmt(body.amount)} opened`);
  await fetchTrades(); await fetchStats();
}

async function placeBinaryTrade() {
  const btn = document.getElementById('binary-submit');
  btn.disabled = true; btn.textContent = 'Placing...';

  const body = {
    userId: USER_ID,
    pair: document.getElementById('b-pair').value,
    direction: state.binDir,
    stake: parseFloat(document.getElementById('b-stake').value),
    expiryMinutes: parseInt(document.getElementById('b-expiry').value),
    payoutPercent: parseInt(document.getElementById('b-payout').value)
  };

  const res = await api('/trade/binary', 'POST', body);
  btn.disabled = false; btn.innerHTML = '<i class="ti ti-bolt"></i> Buy Option';

  if (!res || res.error) { toast(res?.error || 'Failed to place option', true); return; }
  toast(`✓ ${body.direction.toUpperCase()} on ${body.pair} · Expiry: ${body.expiryMinutes}m`);
  await fetchTrades(); await fetchStats();
}

async function closeTrade(id) {
  const res = await api(`/trade/close/${id}`, 'POST');
  if (!res || res.error) { toast(res?.error || 'Failed to close', true); return; }
  const pnl = res.pnl;
  toast(`Position closed · P&L: ${pnl >= 0 ? '+' : ''}$${fmt(Math.abs(pnl))}`);
  await fetchTrades(); await fetchStats();
}

/* ── Deposit / Withdraw ─────────────────────────────────────── */
async function confirmDeposit() {
  const amount = parseFloat(document.getElementById('deposit-amount').value);
  const method = document.querySelector('.method-btn.active span')?.textContent || 'Card';
  const res = await api('/deposit', 'POST', { userId: USER_ID, amount, method });
  if (!res || res.error) { toast(res?.error || 'Deposit failed', true); return; }
  closeModal('deposit-modal');
  toast(`✓ $${fmt(amount)} added to balance`);
  await fetchStats();
}

async function confirmWithdraw() {
  const amount = parseFloat(document.getElementById('withdraw-amount').value);
  const destination = document.getElementById('withdraw-dest').value;
  const res = await api('/withdraw', 'POST', { userId: USER_ID, amount, destination });
  if (!res || res.error) { toast(res?.error || 'Withdrawal failed', true); return; }
  closeModal('withdraw-modal');
  toast(`✓ Withdrawal of $${fmt(amount)} requested`);
  await fetchStats();
}

/* ── Calc helpers ───────────────────────────────────────────── */
function updateForexCalc() {
  const amount = parseFloat(document.getElementById('f-amount')?.value) || 100;
  const lev = parseInt(document.getElementById('f-leverage')?.value) || 50;
  const margin = (amount / lev).toFixed(2);
  const potPnl = (amount * lev * 0.005).toFixed(2);
  const mel = document.getElementById('f-margin'); if (mel) mel.textContent = '$' + fmt(parseFloat(margin));
  const pel = document.getElementById('f-pnl'); if (pel) pel.textContent = '$' + fmt(parseFloat(potPnl));
}

function updateBinaryCalc() {
  const stake = parseFloat(document.getElementById('b-stake')?.value) || 100;
  const pct = parseInt(document.getElementById('b-payout')?.value) || 85;
  const payout = stake * (1 + pct / 100);
  const sd = document.getElementById('b-stake-display'); if (sd) sd.textContent = '$' + fmt(stake);
  const pd = document.getElementById('b-payout-display'); if (pd) pd.textContent = '$' + fmt(payout);
}

/* ── UI Actions ─────────────────────────────────────────────── */
function switchView(v, el) {
  document.querySelectorAll('.view').forEach(d => d.classList.remove('active'));
  const target = document.getElementById('view-' + v);
  if (target) target.classList.add('active');

  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  if (el) el.classList.add('active');

  state.currentView = v;

  if (v === 'binary') setTimeout(initBinaryChartView, 100);
  if (v === 'portfolio') setTimeout(initPortfolioChart, 100);
  if (v === 'history') loadHistory();

  // Close sidebar on mobile
  document.getElementById('sidebar').classList.remove('open');
}

function switchPanel(p, tab) {
  document.getElementById('forex-form').style.display = p === 'forex' ? 'flex' : 'none';
  document.getElementById('binary-form').style.display = p === 'binary' ? 'flex' : 'none';
  document.querySelectorAll('.ptab').forEach(t => t.classList.remove('active'));
  tab.classList.add('active');
}

function setDir(d) {
  state.fxDir = d;
  document.getElementById('f-buy').className = 'dir-btn btn-buy' + (d === 'buy' ? ' active' : '');
  document.getElementById('f-sell').className = 'dir-btn btn-sell' + (d === 'sell' ? ' active' : '');
}

function setBinDir(d) {
  state.binDir = d;
  document.getElementById('b-call').className = 'dir-btn btn-call' + (d === 'call' ? ' active' : '');
  document.getElementById('b-put').className = 'dir-btn btn-put' + (d === 'put' ? ' active' : '');
}

function setTF(el) {
  document.querySelectorAll('.tf').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
}

function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

function selMethod(el) {
  document.querySelectorAll('.method-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

function toggleTheme() {
  document.body.classList.toggle('light');
}

function changeSpeed() {
  const ms = parseInt(document.getElementById('speed-select').value);
  clearInterval(state.tickInterval);
  state.tickInterval = setInterval(async () => {
    await fetchPrices();
    updateTicker();
    updateSidePrices();
    updateCharts();
    updateOpenPositions();
    updateBinaryTimers();
  }, ms);
}

async function loadHistory() {
  const el = document.getElementById('history-list');
  if (!el) return;
  const data = await api(`/transactions/${USER_ID}`);
  if (!data || !data.length) { el.innerHTML = '<div class="empty-state"><i class="ti ti-history"></i><p>No transactions yet.</p></div>'; return; }
  el.innerHTML = data.map(tx => `
    <div class="history-item">
      <div>
        <div style="font-size:13px;font-weight:500;color:var(--text)">${tx.type === 'deposit' ? '⬇ Deposit' : '⬆ Withdrawal'} via ${tx.method || tx.destination || 'Demo'}</div>
        <div style="font-size:11px;color:var(--text-muted)">${new Date(tx.date).toLocaleString()} · <span class="badge badge-${tx.status === 'completed' ? 'open' : 'pending'}">${tx.status}</span></div>
      </div>
      <div style="font-size:15px;font-weight:600" class="${tx.type === 'deposit' ? 'up' : 'down'}">${tx.type === 'deposit' ? '+' : '-'}$${fmt(tx.amount)}</div>
    </div>
  `).join('');
}

/* ── Utilities ──────────────────────────────────────────────── */
function fmt(n) {
  return parseFloat(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fmtPrice(pair, price) {
  if (!price) return '—';
  if (pair.includes('BTC') || pair.includes('ETH')) return '$' + parseFloat(price).toLocaleString('en-US', { maximumFractionDigits: 0 });
  if (pair.includes('XAU') || pair.includes('XAG')) return parseFloat(price).toFixed(2);
  if (pair.includes('JPY')) return parseFloat(price).toFixed(3);
  return parseFloat(price).toFixed(5);
}

let toastTimer;
function toast(msg, isError = false) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = 'toast' + (isError ? ' error' : '');
  el.style.display = 'block';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.style.display = 'none'; }, 3500);
}

// Close modals on backdrop click
document.querySelectorAll('.modal-bg').forEach(m => {
  m.addEventListener('click', e => { if (e.target === m) m.classList.remove('open'); });
});

/* ── Session & Auth ─────────────────────────────────────────── */
function doLogout() {
  localStorage.removeItem('alphafx_session');
  window.location.href = 'login.html';
}

// Load session info and update UI
(function initSession() {
  try {
    const s = JSON.parse(localStorage.getItem('alphafx_session') || '{}');
    if (s && s.name) {
      const initials = s.name.split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase();
      const av = document.getElementById('user-avatar');
      if (av) av.textContent = initials;
    }
    // Sync balance from localStorage users
    if (s && s.userId) {
      const users = JSON.parse(localStorage.getItem('alphafx_users') || '[]');
      const user = users.find(u => u.id === s.userId);
      if (user) {
        balance = user.balance;
        updateBalance();
        USER_ID = user.id;
      }
    }
  } catch(e) {}
})();

// Sync balance back to localStorage on changes
const _origUpdateBalance = updateBalance;
function updateBalance() {
  _origUpdateBalance && _origUpdateBalance();
  try {
    const s = JSON.parse(localStorage.getItem('alphafx_session') || '{}');
    if (!s.userId) return;
    const users = JSON.parse(localStorage.getItem('alphafx_users') || '[]');
    const idx = users.findIndex(u => u.id === s.userId);
    if (idx !== -1) { users[idx].balance = balance; localStorage.setItem('alphafx_users', JSON.stringify(users)); }
  } catch(e) {}
}
